package com.bentruchan.navstacocloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NavsTacoCloudApplicationTests {

	@Test
	void contextLoads() {
	}

}
